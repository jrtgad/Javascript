var REVISION = "Debe ponerse en contacto con EEEE para revisar su vehículo";
    MONTH_STRING = "janfebmaraprmayjunjulaugsepoctnovdec",
    STRING_COMPANIES = "ABERCO|JUMDER|NOIRTE|OSPIA|SAIMTE",
    ERR_MAT = "Número de matrícula incorrecto",
    ERR_DATE_MAT = "Fecha de matriculación incorrecta",
    NO_REVISION = "Su vehículo no necesita revisión",
    MSECTODAYS = 3600 * 24000;